# wasabit
The Wasabit module is a complete file management tool with integrated upload, download and authentication features.
